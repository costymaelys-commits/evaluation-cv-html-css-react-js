/* ==============================
   Le Carnet Gourmand
   Gestion des commentaires
   ============================== */

const commentForm = document.querySelector("#comment-form");
const authorInput = document.querySelector("#author");
const commentInput = document.querySelector("#comment-text");
const commentsList = document.querySelector("#comments-list");
const formMessage = document.querySelector("#form-message");

// Affiche un message d'erreur sous le formulaire.
function showError(message) {
  formMessage.textContent = message;
  formMessage.hidden = false;
}

// Masque le message d'erreur.
function hideError() {
  formMessage.textContent = "";
  formMessage.hidden = true;
}

// Crée une carte de commentaire sans utiliser innerHTML.
function createComment(author, comment) {
  const commentArticle = document.createElement("article");
  commentArticle.classList.add("comment-item");

  const authorTitle = document.createElement("h3");
  authorTitle.classList.add("comment-author");
  authorTitle.textContent = author;

  const commentParagraph = document.createElement("p");
  commentParagraph.classList.add("comment-content");
  commentParagraph.textContent = comment;

  const deleteButton = document.createElement("button");
  deleteButton.classList.add("delete-button");
  deleteButton.type = "button";
  deleteButton.textContent = "🗑️ Supprimer";
  deleteButton.setAttribute(
    "aria-label",
    "Supprimer le commentaire de " + author
  );

  // Supprime uniquement la carte associée au bouton cliqué.
  deleteButton.addEventListener("click", function () {
    commentArticle.remove();
  });

  commentArticle.appendChild(authorTitle);
  commentArticle.appendChild(commentParagraph);
  commentArticle.appendChild(deleteButton);

  return commentArticle;
}

// Gère la soumission du formulaire.
commentForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const author = authorInput.value.trim();
  const comment = commentInput.value.trim();

  if (author.length < 2) {
    showError("Le nom doit contenir au moins 2 caractères.");
    authorInput.focus();
    return;
  }

  if (comment.length < 10) {
    showError("Le commentaire doit contenir au moins 10 caractères.");
    commentInput.focus();
    return;
  }

  const newComment = createComment(author, comment);
  commentsList.appendChild(newComment);

  commentForm.reset();
  hideError();
  authorInput.focus();
});

// Active la suppression des commentaires déjà présents dans le HTML.
const initialDeleteButtons = document.querySelectorAll(".delete-button");

initialDeleteButtons.forEach(function (button) {
  button.addEventListener("click", function () {
    const commentCard = button.closest(".comment-item");

    if (commentCard) {
      commentCard.remove();
    }
  });
});
