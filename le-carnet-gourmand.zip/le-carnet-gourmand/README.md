## Arborescence
```text
le-carnet-gourmand/
├── index.html
└── assets/
    ├── css/
    │   └── style.css
    └── js/
        └── script.js
```